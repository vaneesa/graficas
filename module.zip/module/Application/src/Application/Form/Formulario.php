<?php 
namespace Application\Form;

use Application\Model\GraficasModel;
use Prophecy\Comparator\Factory;
use Zend\Form\Form;
use Zend\Form\Element;


class Formulario extends Form
{
    private $graficasModel;
    
    
    private function getGraficasModel()
    {
        return $this->graficasModel = new GraficasModel();
    }
    
    
//     public function __construct($name = null)
//     {
// //         parent::__construct($name);
// //         $factory = new Factory();
        
// //         $graficaSimulacro = $this->getGraficasModel()->busqueda();
        
// // //         print_r("llegue");
// // //         print_r($graficaSimulacro[]['id']);
        
// //         $select = new Element\Select('nombreSimulacro');
// //         $select->setLabel('Simulacro ');
// // //         $select->setAttribute('multiple', true);
// //         $select->setEmptyOption('Seleccione...');
// //         $i="";
// //         $array= array();
        
// //         foreach($graficaSimulacro as $row){
// // //             $i .= $row['tagGrupal'];
// //             array_push($array,$row['tagGrupal']);
// //             $select->setValueOptions($array);
            
// //         }
// // //         print_r($select->getValueOptions($array[0][0]));
// // //         exit;
// //         $this->add($select);
        
        
// //         *******************************
//         parent::__construct($name);
//         $factory = new Factory();
        
//         $graficaSimulacro = $this->getGraficasModel()->busqueda();
        
//         //         print_r("llegue");
//         //         print_r($graficaSimulacro);exit;
        
//         $select = new Element\Select('nombreSimulacro');
//         $select->setLabel('Simulacro ');
//         //         $select->setAttribute('multiple', true);
//         $select->setEmptyOption('Seleccione...');
//         //         $select->setValueOptions(array(
//         //                     'simulacro' => $graficaSimulacro
//         //                 ));
        
// //         $valor = array(
// //             '0' => $graficaSimulacro['id'],
// //             '1' => 'English',
// //             '2' => 'Japanese',
// //             '3' => 'Chinese',
// //         );
//         $valor;
// //         print_r(count($graficaSimulacro));exit;
//         foreach($graficaSimulacro as $row){
        
//             //array_push($valor,$row['tagGrupal']);
//             $valor = array(
//                 $row['id'] => $row['tagGrupal'],
//             );
            
            
//         }
// //         array_push($valor);
//         $select->setValueOptions($valor);
        
        
//         $this->add($select);
// //         *******************************
        
//         $this->add(array(
//             'name' => 'send',
//             'attributes' => array(
//                 'type' => 'submit',
//                 'value' => 'Enviar',
//                 'title' => 'Enviar'
//             ),
//         ));
//     }
// }

    
    
    public function __construct($name = null)
    {
        parent::__construct($name);
        $factory = new Factory();
        
        $graficaSimulacro = $this->getGraficasModel()->busqueda();
        
        //         print_r("llegue");
        //         print_r($graficaSimulacro);exit;
        
        $select = new Element\Select('nombreSimulacro');
        $select->setLabel('Simulacro ');
        //         $select->setAttribute('multiple', true);
        $select->setEmptyOption('Seleccione...');
        
        
        
        $valor = array();
        
        foreach($graficaSimulacro as $row){
            
            $f = array($row['id'] => $row['tagGrupal']);
            
            $valor =array_merge($valor,$f);
            
        }
        
        //         print_r($valor);exit;
        
        $select->setValueOptions($valor);
        
        
        $this->add($select);
        
        
        
        
        //         $marcaModel = new Application_Model_Marca();
        //         $rowset = $marcaModel->listarMarcas();
        //         foreach($rowset as $row){
        //             $marcaSelect->addMultiOption($row->id_marca, $row->nombre_marca);
        //         }
        
        $this->add(array(
            'name' => 'send',
            'attributes' => array(
                'type' => 'submit',
                'value' => 'Enviar',
                'title' => 'Enviar'
            ),
        ));
    }
}

?>